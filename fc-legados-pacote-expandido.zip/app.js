const KEY="fc_legados_25_ligas_v1";const $=id=>document.getElementById(id);
let db=load();
function load(){try{return JSON.parse(localStorage.getItem(KEY))||{player:null,fixtures:[],table:{},history:[],round:0};}catch{return {player:null,fixtures:[],table:{},history:[],round:0};}}
function save(){localStorage.setItem(KEY,JSON.stringify(db));render();}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function log(msg){db.history.unshift({date:new Date().toLocaleDateString("pt-BR"),msg});}
function leagueById(id){return LEAGUES.find(x=>x.id===id);}
function leagueForPlayer(){return db.player?leagueById(db.player.leagueId):null;}
function fillCountries(select,selected){select.innerHTML=LEAGUES.map(l=>`<option value="${l.id}" ${l.id===selected?"selected":""}>${esc(l.country)} — ${esc(l.name)}</option>`).join("");}
function fillClubs(select,leagueId,selected){const l=leagueById(leagueId);select.innerHTML=l.teams.map(t=>`<option ${t===selected?"selected":""}>${esc(t)}</option>`).join("");}
function syncCreate(){const id=$("countrySelect").value;fillClubs($("clubSelect"),id);$("leagueSelect").innerHTML=`<option>${esc(leagueById(id).name)} (${esc(leagueById(id).season)})</option>`;}
function setup(){fillCountries($("countrySelect"),"bra");syncCreate();$("countrySelect").addEventListener("change",syncCreate);
 fillCountries($("browseCountry"),"bra");$("browseCountry").addEventListener("change",showLeagueInfo);showLeagueInfo();
 fillCountries($("transferCountry"),"bra");syncTransfer();$("transferCountry").addEventListener("change",syncTransfer);$("transferLeague").addEventListener("change",syncTransferClub);
}
function syncTransfer(){const l=leagueById($("transferCountry").value);$("transferLeague").innerHTML=`<option value="${l.id}">${esc(l.name)}</option>`;syncTransferClub();}
function syncTransferClub(){fillClubs($("transferClub"),$("transferLeague").value);}
function showLeagueInfo(){const l=leagueById($("browseCountry").value);$("leagueInfo").innerHTML=`<h3>${esc(l.country)} — ${esc(l.name)}</h3><p class="muted">Temporada de referência: ${esc(l.season)} • ${l.teams.length} clubes cadastrados</p><div class="club-grid">${l.teams.map((t,i)=>`<div class="club">${i+1}. ${esc(t)}</div>`).join("")}</div>`;}
function createFixtures(l){let teams=[...l.teams];if(teams.length%2)teams.push("BYE");let arr=[],n=teams.length;let rot=[...teams];for(let r=0;r<n-1;r++){for(let i=0;i<n/2;i++){let a=rot[i],b=rot[n-1-i];if(a!=="BYE"&&b!=="BYE"){arr.push({round:r+1,home:a,away:b,played:false,leg:1});arr.push({round:r+n,home:b,away:a,played:false,leg:2});}}rot=[rot[0],rot[n-1],...rot.slice(1,n-1)];}return arr;}
function initTable(l){let t={};l.teams.forEach(name=>t[name]={club:name,p:0,w:0,d:0,l:0,gf:0,ga:0,gd:0,pts:0});return t;}
function standings(){const p=db.player,l=leagueForPlayer();if(!p||!l)return;return Object.values(db.table).sort((a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf);}
function render(){
 const p=db.player;$("saveStatus").textContent=p?`Carreira: ${p.name}`:"Nenhuma carreira";
 $("dashboard").innerHTML=p?`<div class="card">JOGADOR<strong>${esc(p.name)}</strong><small>${esc(p.club)} · ${esc(p.position)}</small></div><div class="card">OVR<strong>${p.ovr}</strong><small>Potencial ${p.potential}</small></div><div class="card">GOLS<strong>${p.goals}</strong><small>${p.assists} assistências</small></div><div class="card">PARTIDAS<strong>${p.apps}</strong><small>Temporada ${p.season}</small></div>`:`<div class="card">FC LEGADOS<strong>25</strong><small>Ligas disponíveis</small></div><div class="card">CLUBES<strong>${LEAGUES.reduce((n,l)=>n+l.teams.length,0)}</strong><small>Clubes cadastrados</small></div><div class="card">CARREIRA<strong>—</strong><small>Crie seu jogador</small></div><div class="card">TEMPORADA<strong>—</strong><small>Aguardando início</small></div>`;
 if(p){$("playerProfile").classList.remove("hidden");$("playerProfile").innerHTML=`<h3>${esc(p.name)} <span style="color:var(--gold)">· ${p.ovr} OVR</span></h3><p>${esc(p.club)} — ${esc(p.country)} / ${esc(p.leagueName)}</p><p>${p.age} anos · ${p.height} cm · ${esc(p.nation)} · ${esc(p.position)} · camisa ${p.number}</p><p>Origem: ${esc(p.origin)} · Potencial: ${p.potential}</p>`;renderCalendar();renderTable();renderNextMatch();}
 else{$("playerProfile").classList.add("hidden");$("calendarBox").textContent="Crie uma carreira para gerar o calendário."; $("tableBox").textContent="A classificação aparecerá após criar a carreira."; $("nextMatch").textContent="Crie uma carreira primeiro.";}
 $("historyBox").innerHTML=db.history.length?db.history.map(h=>`<div class="history-row"><span>${esc(h.msg)}</span><small>${h.date}</small></div>`).join(""):"Nenhum registro ainda.";
}
function renderCalendar(){const l=leagueForPlayer();const upcoming=db.fixtures.filter(f=>!f.played).slice(0,16);$("calendarBox").innerHTML=`<p>${esc(l.name)} ${esc(l.season)} — ${l.teams.length} clubes — ${db.fixtures.length} jogos no calendário (ida e volta).</p>`+upcoming.map(f=>`<div class="fixture"><span>Rodada ${f.round}</span><b>${esc(f.home)} × ${esc(f.away)}</b><small>${f.played?"Concluída":"Pendente"}</small></div>`).join("");}
function renderTable(){const rows=standings();$("tableBox").innerHTML=`<p>${esc(leagueForPlayer().name)} — ${esc(db.player.club)}</p><div style="overflow-x:auto"><table><thead><tr><th>#</th><th>Clube</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th><th>PTS</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.club)}</td><td>${r.p}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gd}</td><td><b>${r.pts}</b></td></tr>`).join("")}</tbody></table></div>`;}
function renderNextMatch(){const p=db.player;const f=db.fixtures.find(x=>!x.played&&(x.home===p.club||x.away===p.club));$("nextMatch").innerHTML=f?`<h3>${esc(f.home)} <span style="color:var(--gold)">×</span> ${esc(f.away)}</h3><p class="muted">${esc(leagueForPlayer().name)} · Rodada ${f.round}</p>`:"Não há partidas pendentes para o clube nesta temporada.";}
function updateTable(f,hg,ag){let h=db.table[f.home],a=db.table[f.away];h.p++;a.p++;h.gf+=hg;h.ga+=ag;a.gf+=ag;a.ga+=hg;h.gd=h.gf-h.ga;a.gd=a.gf-a.ga;if(hg>ag){h.w++;h.pts+=3;a.l++;}else if(hg<ag){a.w++;a.pts+=3;h.l++;}else{h.d++;a.d++;h.pts++;a.pts++;}}
$("createForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.currentTarget),origin=f.get("origin");const ranges={"Promessa":[67,74,88,94],"Filho de jogador":[65,72,85,93],"Jogador comum":[58,66,78,86],"Joia desconhecida":[55,65,90,96],"Veterano":[69,77,76,84],"Superação":[57,68,84,92]};const r=ranges[origin];const l=leagueById($("countrySelect").value);const old=db.player;
 db.player={name:f.get("name").trim(),shirt:f.get("shirt")||f.get("name"),age:+f.get("age"),height:+f.get("height"),nation:f.get("nation"),position:f.get("position"),foot:f.get("foot"),origin,country:l.country,leagueId:l.id,leagueName:l.name,club:$("clubSelect").value,number:old?.number||10,ovr:old?.ovr||(r[0]+Math.floor(Math.random()*(r[1]-r[0]+1))),potential:old?.potential||(r[2]+Math.floor(Math.random()*(r[3]-r[2]+1))),goals:old?.goals||0,assists:old?.assists||0,apps:old?.apps||0,season:old?.season||1};
 db.fixtures=createFixtures(l);db.table=initTable(l);db.round=0;log(`Carreira iniciada no ${db.player.club}, ${l.name} (${l.country}). Calendário de ida e volta criado.`);save();alert("Carreira criada e calendário gerado.");});
$("simulate").addEventListener("click",()=>{if(!db.player)return alert("Crie uma carreira primeiro.");const f=db.fixtures.find(x=>!x.played&&(x.home===db.player.club||x.away===db.player.club));if(!f)return alert("Não há partidas pendentes.");const hg=Math.floor(Math.random()*5),ag=Math.floor(Math.random()*5);f.played=true;f.score=`${hg} x ${ag}`;updateTable(f,hg,ag);const p=db.player;let pg=0,pa=0;if(Math.random()<.7)pg=Math.min(hg,Math.floor(Math.random()*3));if(Math.random()<.5)pa=Math.min(Math.max(0,hg-pg),Math.floor(Math.random()*2));p.apps++;p.goals+=pg;p.assists+=pa;log(`${f.home} ${hg} x ${ag} ${f.away}. ${p.name}: ${pg} gol(s), ${pa} assistência(s).`);save();alert(`Resultado: ${f.home} ${hg} x ${ag} ${f.away}\\n${p.name}: ${pg} gol(s), ${pa} assistência(s).`);});
$("deleteCareer").addEventListener("click",()=>{if(confirm("Apagar a carreira e o calendário salvos neste navegador?")){db={player:null,fixtures:[],table:{},history:[],round:0};save();}});
$("transferCountry").addEventListener("change",()=>{fillCountries($("transferCountry"),$("transferCountry").value);syncTransfer();});
$("transfer").addEventListener("click",()=>{if(!db.player)return alert("Crie uma carreira primeiro.");const l=leagueById($("transferLeague").value),club=$("transferClub").value;const old=db.player.club;db.player.club=club;db.player.country=l.country;db.player.leagueId=l.id;db.player.leagueName=l.name;db.fixtures=createFixtures(l);db.table=initTable(l);log(`Transferência registrada: ${old} → ${club} (${l.name}, ${l.country}). Nova temporada de liga gerada.`);save();alert("Transferência registrada. Calendário e classificação reiniciados para a nova liga.");});
$("export").addEventListener("click",()=>{const blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="fc-legados-backup.json";a.click();URL.revokeObjectURL(a.href);});
$("import").addEventListener("change",async e=>{const file=e.target.files[0];if(!file)return;try{const x=JSON.parse(await file.text());if(!x||!Array.isArray(x.fixtures)||!x.player)throw Error();db=x;save();alert("Backup importado.");}catch{alert("Backup inválido.");}e.target.value="";});
document.querySelectorAll("[data-tab]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));$("tab-"+b.dataset.tab).classList.add("active");document.querySelectorAll("[data-tab]").forEach(x=>x.classList.toggle("active",x===b));$("nav").classList.remove("open");window.scrollTo(0,0);}));
document.querySelectorAll("[data-jump]").forEach(b=>b.addEventListener("click",()=>{document.querySelector('[data-tab="'+b.dataset.jump+'"]').click();}));
$("hamb").addEventListener("click",()=>$("nav").classList.toggle("open"));
setup();render();

// Sistemas adicionais da carreira: evolução, eventos, imprensa e seleção.
function ensureExtended(){
 if(!db.player)return;
 const p=db.player;
 p.attributes ||= {pace:75,shooting:65,passing:66,dribbling:76,defending:35,physical:60};
 p.popularity ??= 1000; p.followers ??= 250; p.national ||= {apps:0,goals:0,assists:0,matches:[]};
}
function renderExtended(){
 if(!db.player)return;
 ensureExtended();
 const p=db.player, a=p.attributes;
 const labels={pace:"Velocidade",shooting:"Finalização",passing:"Passe",dribbling:"Drible",defending:"Defesa",physical:"Físico"};
 $("attributes").innerHTML=`<h3>${esc(p.name)} · ${p.ovr} OVR · Potencial ${p.potential}</h3><div class="club-grid">${Object.entries(labels).map(([k,v])=>`<div class="club"><b>${v}</b><strong style="float:right;color:var(--gold)">${a[k]}</strong><div style="height:6px;background:#333;margin-top:8px;border-radius:8px"><div style="height:6px;width:${Math.min(100,a[k])}%;background:var(--gold);border-radius:8px"></div></div></div>`).join("")}</div>`;
 $("mediaBox").innerHTML=`<div class="cards"><div class="card">POPULARIDADE<strong>${p.popularity.toLocaleString("pt-BR")}</strong></div><div class="card">SEGUIDORES<strong>${p.followers.toLocaleString("pt-BR")}</strong></div><div class="card">REPUTAÇÃO<strong>${p.popularity>10000?"Destaque":p.popularity>3000?"Em ascensão":"Promessa"}</strong></div></div><h3>Últimas manchetes</h3>${db.history.slice(0,8).map(x=>`<div class="history-row">${esc(x.msg)}</div>`).join("")}`;
 $("nationalBox").innerHTML=`<h3>${esc(p.nation)} — Seleção</h3><p>Jogos: ${p.national.apps} · Gols: ${p.national.goals} · Assistências: ${p.national.assists}</p>${p.national.matches.slice(0,10).map(m=>`<div class="history-row">${esc(m.result)} — ${m.goals}G / ${m.assists}A</div>`).join("")}`;
}
$("createForm").addEventListener("submit",()=>setTimeout(()=>{ensureExtended();save();},0));
$("train").addEventListener("click",()=>{
 if(!db.player)return alert("Crie uma carreira primeiro.");
 ensureExtended(); const p=db.player, key=$("training").value;
 const gain=Math.random()<.72?1:2;
 if(p.attributes[key]>=99)return alert("Esse atributo já está no máximo.");
 p.attributes[key]=Math.min(99,p.attributes[key]+gain);
 if(p.ovr<p.potential && Math.random()<.22)p.ovr++;
 log(`Treino realizado: ${key}. Evolução de ${gain} ponto(s) no atributo.`);
 save();renderExtended();alert(`Treino concluído! +${gain} em ${key}.`);
});
$("newEvent").addEventListener("click",()=>{
 if(!db.player)return alert("Crie uma carreira primeiro.");
 ensureExtended();
 const p=db.player, events=[
  {q:"O treinador oferece a chance de cobrar um pênalti decisivo. Você aceita?",yes:"Você converte a cobrança e ganha confiança.",no:"Você prefere deixar a cobrança para outro companheiro.",effect:()=>{p.popularity+=250;p.followers+=80;}},
  {q:"A imprensa questiona sua sequência de jogos. Como responde?",yes:"Você responde com personalidade e promete trabalhar.",no:"Você evita polêmica e mantém o foco.",effect:()=>{p.popularity+=100;p.followers+=35;}},
  {q:"Um jovem da base pede conselhos após o treino. Você ajuda?",yes:"Você orienta o jovem e ganha respeito no elenco.",no:"Você prefere descansar após a atividade.",effect:()=>{p.popularity+=150;}},
  {q:"O treinador propõe um treino extra de finalização. Você aceita?",yes:"O treino extra melhora sua finalização.",no:"Você preserva energia para a próxima partida.",effect:()=>{p.attributes.shooting=Math.min(99,p.attributes.shooting+1);}}
 ];
 const ev=events[Math.floor(Math.random()*events.length)];
 $("eventBox").innerHTML=`<h3>${ev.q}</h3><button class="gold" id="eventYes">Aceitar / Sim</button> <button class="outline" id="eventNo">Recusar / Não</button>`;
 $("eventYes").onclick=()=>{ev.effect();log(ev.yes);$("eventBox").textContent=ev.yes;save();renderExtended();};
 $("eventNo").onclick=()=>{log(ev.no);$("eventBox").textContent=ev.no;save();};
});
$("addNational").addEventListener("click",()=>{
 if(!db.player)return alert("Crie uma carreira primeiro.");
 ensureExtended();const result=$("nationalResult").value.trim();if(!result)return alert("Informe o resultado da partida.");
 const goals=Math.max(0,+$("nationalGoals").value||0),assists=Math.max(0,+$("nationalAssists").value||0),n=db.player.national;
 n.apps++;n.goals+=goals;n.assists+=assists;n.matches.unshift({result,goals,assists});
 log(`Seleção: ${result}. ${db.player.name}: ${goals} gol(s), ${assists} assistência(s).`);
 $("nationalResult").value="";$("nationalGoals").value=0;$("nationalAssists").value=0;save();renderExtended();
});
const originalRender=render;
render=function(){originalRender();renderExtended();};
ensureExtended();render();
