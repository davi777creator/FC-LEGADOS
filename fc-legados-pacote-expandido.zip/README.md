# FC LEGADOS — pacote expandido

## Como publicar
1. Extraia este ZIP.
2. Envie TODOS os arquivos para a raiz do repositório GitHub (mesma pasta de `index.html`).
3. Faça o commit.
4. No GitHub, abra Settings > Pages > Deploy from a branch > `main` > `/ (root)` > Save.

## Arquivos
- `index.html`: estrutura e telas.
- `style.css`: visual responsivo.
- `leagues.js`: base inicial de 25 ligas e clubes.
- `app.js`: lógica do simulador.
- `README.md`: estas instruções.

## Recursos incluídos nesta versão
- Criação de jogador e escolha de origem, posição, idade, nacionalidade, clube e liga.
- OVR e potencial iniciais estimados conforme origem.
- 25 ligas e base inicial de clubes.
- Calendário de ida e volta e classificação.
- Simulação textual simplificada de partidas.
- Registro de gols, assistências e jogos pelo clube.
- Transferência manual entre clubes e ligas.
- Treinos e evolução simplificada de atributos/OVR.
- Eventos narrativos com escolhas e consequências.
- Imprensa, popularidade e seguidores simulados.
- Estatísticas da seleção separadas das estatísticas do clube.
- Histórico, backup e importação/exportação local.

## Limitações importantes
Este é um protótipo front-end expandido, não a implementação integral de todos os recursos idealizados para o FC LEGADOS.
- Os dados das ligas são uma base inicial de referência e precisam de revisão por temporada; não são garantidos como oficiais/atualizados.
- A simulação de partidas, evolução, eventos, imprensa e seleção é simplificada.
- A convocação/partidas da seleção são registradas manualmente; não existe calendário internacional automático.
- As transferências são manuais; ainda não há propostas automáticas, negociação salarial/contratual ou janelas realistas.
- Ainda não há contas, login, banco de dados remoto, sincronização entre aparelhos ou salvamento online. Os dados ficam no armazenamento local do navegador.
- Ainda não estão implementados motor de jogo visual, regras especiais completas de cada liga, formatos de playoffs, torneios continentais, Copa do Mundo, promoções/rebaixamentos automáticos, lesões completas, premiações e mercado independente de treinadores.
- O projeto foi montado, mas precisa ser testado no navegador após a publicação. Não é possível garantir ausência de bugs sem esse teste.

Para manter os saves, use Exportar backup antes de limpar os dados do navegador ou trocar de aparelho.
